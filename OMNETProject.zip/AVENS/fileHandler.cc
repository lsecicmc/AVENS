//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "fileHandler.h"
#include "tinyxml.h"

Define_Module(FileHandler);

#define RAIO_TERRA  ((double) 6371000)  // 6371000 metros
//#define RAIO_TERRA  1  // 6371000 metros

inet::Coord * xCoordReferences = NULL;

#define dToRadians(degrees) ((degrees * M_PI) / 180)

typedef enum {XYZ_COORD,LAT_LONG} typeOfData;

int eDataType;

inet::Coord * FileHandler::xConvertToXYZ(double dLatitude, double dLongitude,
        double dElevation) {

    inet::Coord * xCoordinates = new inet::Coord(0, 0, 0);

    xCoordinates->x = RAIO_TERRA * cos(dToRadians(dLatitude)) * cos(dToRadians(dLongitude));
    xCoordinates->y = RAIO_TERRA * cos(dToRadians(dLatitude)) * sin(dToRadians(dLongitude));
    xCoordinates->z = dElevation/1000;

    return xCoordinates;
}


void FileHandler::initialize()
{
    int iNumberOfPlanes = (int) getParentModule()->par("numHosts").longValue();
    eDataType = (int) par("typeofData").longValue();

    std::cout <<"Initialize FileSPOC" <<std::endl;
    std::cout << "Type of data = " << eDataType << std::endl;
    // Create file with initial configuration data
    TiXmlDocument xconfigDocument(par("filename").stringValue());

    // Create number of planes and add it
    TiXmlElement xNumberOfPlanes("Number_of_Planes");
    xNumberOfPlanes.SetAttribute("value", iNumberOfPlanes);
    xconfigDocument.InsertEndChild(xNumberOfPlanes);

    // Create field for Latitude and Longitude references
    TiXmlElement xCoordReferences("Coord_References");
    xCoordReferences.SetDoubleAttribute("Latitude", 0.0);
    xCoordReferences.SetDoubleAttribute("Longitude", 0.0);
    xCoordReferences.SetDoubleAttribute("Elevation", 0.0);
    xconfigDocument.InsertEndChild(xCoordReferences);

    // Create FANET
    TiXmlElement xFANET("FANET");
    for (int i = 0; i < iNumberOfPlanes; i++) {
        // Create Aircraft and its id's
        TiXmlElement xAircraft("Aircraft");
        xAircraft.SetAttribute("id", i);
        xAircraft.SetDoubleAttribute("Latitude", 0.0);
        xAircraft.SetDoubleAttribute("Longitude", 0.0);
        xAircraft.SetDoubleAttribute("Elevation", 0.0);
        xAircraft.SetDoubleAttribute("XPosition", 0.0);
        xAircraft.SetDoubleAttribute("YPosition", 0.0);
        xAircraft.SetDoubleAttribute("ZPosition", 0.0);
        xFANET.InsertEndChild(xAircraft);
    }
    xconfigDocument.InsertEndChild(xFANET);

    // Create boolean control flag.
    TiXmlElement xXPlaneRead("Read_by_Xplane");
    xXPlaneRead.SetAttribute("value", "FALSE");
    xconfigDocument.InsertBeforeChild(xconfigDocument.FirstChild(),
            xXPlaneRead);

    if (xconfigDocument.SaveFile() == false)
        std::cout << "Could not save file" << std::endl;

    cMessage * xMsg = new cMessage("WAIT_XPLANE");
    scheduleAt(0, xMsg);
}

void FileHandler::handleMessage(cMessage *msg)
{
    TiXmlDocument xConfigDocument(par("filename").stringValue());
    int iNumberOfPlanes = (int) getParentModule()->par(par("numHostVariableName").stringValue()).longValue();

    if(strcmp(msg->getName(),"WAIT_XPLANE") == 0){
        // Wait for XPlane to insert initial positions
        std::cout << "WAIT_XPLANE received by fileHandler." << std::endl;

        if (xConfigDocument.LoadFile() == false) {
            // If file can't be loaded, try again later.
            std::cout << "Could not load file." << endl;
            scheduleAt(simTime() + 1.5,msg);
            return;
        }

        // Verify if XPlane has initialized values
        TiXmlElement * xFlag =
                xConfigDocument.FirstChildElement("Read_by_Xplane");
        bool bReadByXPlane;
        xFlag->QueryBoolAttribute("value", &bReadByXPlane);
        if (bReadByXPlane == FALSE) {
            // If not, wait for it.
            scheduleAt(simTime() + 1.5, msg);
        } else {
            // Otherwise, read initial positions and references.
            scheduleAt((simTime() + 1), new cMessage("GET_REFERENCES"));
            delete msg;
        }
        return;
    }
    if(strcmp(msg->getName(),"GET_REFERENCES") == 0){

        if(xConfigDocument.LoadFile() == false){
            // File can't be loaded, try again later.
            std::cout << "Could not load file." << std::endl;
            scheduleAt(simTime() + 1.5, msg);
            return;
        }

        std::cout << "File loaded" << std::endl;
        TiXmlElement * xNET;
        switch(eDataType){
        case XYZ_COORD:
            // Get initial position of Plane 0 as referenca
            xNET = xConfigDocument.FirstChildElement("FANET");
            if(xNET == NULL){
                std::cout << "xFANET lookup returned NULL value." << std::endl;
                assert(xNET);
            }else{
                std::cout << "Got FANET" << std::endl;
                TiXmlElement * xAircraft0 = xNET->FirstChildElement("Aircraft");
                if(xAircraft0 == NULL){
                    std::cout << "xAircraft0 lookup returned NULL value." << std::endl;
                    assert(xAircraft0);
                }else{
                    std::cout << "Got Aircraft reference." << std::endl;
                    double dXRef, dYRef, dZRef;
                    xAircraft0->Attribute("XPosition", &dXRef);
                    xAircraft0->Attribute("YPosition", &dYRef);
                    xAircraft0->Attribute("ZPosition", &dZRef);

                    // In X-Plane, the Height is in Y-axis
                    xCoordReferences = new inet::Coord(dXRef,dZRef,dYRef);

                    std::cout << "XYZ References: (" << xCoordReferences->x << ",";
                    std::cout << xCoordReferences->y << "," << xCoordReferences->z << ")." << std::endl;
                }
            }
            break;
        case LAT_LONG:
            // If file was successfully loaded, get references.
            TiXmlElement * xReferences = xConfigDocument.FirstChildElement("Coord_References");
            if(xReferences == NULL){
                std::cout << "xReferences lookup returned NULL value." << std::endl;
                assert(xReferences);
            }else{
                double dLatitudeRef, dLongitudeRef, dElevationRef;
                xReferences->Attribute("Latitude",&dLatitudeRef);
                xReferences->Attribute("Longitude", &dLongitudeRef);
                xReferences->Attribute("Elevation", &dElevationRef);
                std::cout << "References read: \nLatitude: " << dLatitudeRef << "\nLongitude: ";
                std::cout << dLongitudeRef << "\nElevation: " << dElevationRef << std::endl;
                xCoordReferences = xConvertToXYZ(dLatitudeRef,dLongitudeRef,dElevationRef);
                std::cout << "XYZ References: (" << xCoordReferences->x << ",";
                std::cout << xCoordReferences->y << "," << xCoordReferences->z << ")." << std::endl;
            }
            break;

        }
        // Update positions immediately
        scheduleAt(simTime(), new cMessage("UPDATE_POSITIONS"));
        delete msg;
        return;
    }

    // O erro aparece aqui
    std::cout << "getName " << msg->getName() << endl;
    if(strcmp(msg->getName(),"UPDATE_POSITIONS") == 0){
        // Update Aircraft from file values
        std::cout << "UPDATE_POSITIONS received by fileHandler." << std::endl;

        // Load file
        if (xConfigDocument.LoadFile() == false) {
            // If file can't be loaded, try again later.
            std::cout << "Could not load file." << endl;
            scheduleAt(simTime() + 1.5,msg);
            return;
        }

        // Get FANET item from file
        TiXmlElement * xFANET = xConfigDocument.FirstChildElement("FANET");
        if(xFANET == NULL){
            std::cout << "'FANET' could not be found. Please check XML file." << std::endl;
            assert(xFANET);
        }

        TiXmlNode * xAircraftFileNode = NULL;

        // For each Aircraft, get data from file
        for(int a = 0; a < iNumberOfPlanes; a++){

            // Get next plane in file.
            xAircraftFileNode = xFANET->IterateChildren("Aircraft",xAircraftFileNode);
            if(xAircraftFileNode == NULL){
                std::cout << "Can't find planes. XML file corrupted." << std::endl;
                assert(xAircraftFileNode);
            }
            TiXmlElement * xAircraftFileElement = xAircraftFileNode->ToElement();

            // Read its parameters
            inet::Coord * xAirplaneCoord;
            switch(eDataType){
            case XYZ_COORD:
                xAirplaneCoord = new inet::Coord();
                // In X-Plane, the Height is in Y-axis
                xAircraftFileElement->Attribute("XPosition",&(xAirplaneCoord->x));
                xAircraftFileElement->Attribute("YPosition", &(xAirplaneCoord->z));
                xAircraftFileElement->Attribute("ZPosition", &(xAirplaneCoord->y));
                break;
            case LAT_LONG:
                double dLatitude, dLongitude, dElevation;
                xAircraftFileElement->Attribute("Latitude",&dLatitude);
                xAircraftFileElement->Attribute("Longitude", &dLongitude);
                xAircraftFileElement->Attribute("Elevation", &dElevation);

                // Reference them
                xAirplaneCoord = xConvertToXYZ(dLatitude,dLongitude,dElevation);
                break;
            }

            xAirplaneCoord->x = xAirplaneCoord->x - xCoordReferences->x;
            xAirplaneCoord->y = xAirplaneCoord->y - xCoordReferences->y;
            xAirplaneCoord->z = xAirplaneCoord->z - xCoordReferences->z;

            // Update positions in mobility
            cModule * xAircraftModule = getParentModule()->getSubmodule(par("hostVariableName").stringValue(),a);
            assert(xAircraftModule);
            std::cout << "Aircraft module found correctly." << std::endl;

            // Update Aircraft parameters
            // TODO --- Insert Here!!

            cModule * xAircraftMobilityModule = xAircraftModule->getSubmodule("mobility",0);
            assert(xAircraftMobilityModule);
            std::cout << "Mobility module found correctly." << std::endl;

            // Update values in mobility
            xAircraftMobilityModule->par("dXPosition").setDoubleValue(xAirplaneCoord->x);
            xAircraftMobilityModule->par("dYPosition").setDoubleValue(xAirplaneCoord->y);
            xAircraftMobilityModule->par("dZPosition").setDoubleValue(xAirplaneCoord->z);
        }
        scheduleAt(simTime() + 1, msg);
    }
}
