/*
 * Aircraft.h
 *
 *  Created on: 26/05/2016
 *      Author: Mariana
 */

#ifndef AIRCRAFT_H_
#define AIRCRAFT_H_

#include <csimplemodule.h>

class Aircraft: public cSimpleModule {
protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg);
};

#endif /* AIRCRAFT_H_ */
