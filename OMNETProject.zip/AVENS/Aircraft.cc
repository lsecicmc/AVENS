/*
 * Aircraft.cpp
 *
 *  Created on: 26/05/2016
 *      Author: Mariana
 */

#include <Aircraft.h>
#include <cmessage.h>
#include <cnamedobject.h>
#include <cobjectfactory.h>
#include <cregistrationlist.h>
#include <csimulation.h>
#include <regmacros.h>
#include <simtime.h>
#include <simutil.h>
#include <cstring>
#include <iostream>
#include "inet/mobility/single/ArbitraryMobility.h"

//using namespace inet;

Define_Module(Aircraft);


void Aircraft::initialize(){
}

void Aircraft::handleMessage(cMessage *msg){

}
